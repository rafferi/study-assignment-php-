<?php
define('BASE_URL', 'http://localhost/site/');
