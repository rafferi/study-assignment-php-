<?php
$host = 'localhost';
$data = 'mysite';
$user = 'root';
$pass = 'mysql';
?>